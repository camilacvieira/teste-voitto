<!DOCTYPE html>
<html lang="pr-br">
<head>
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	
	<title>Camila Teste Voitto</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
</head>

<body>
	
	<?php include_once("conexao.php");
	?>
	<div class="container">
		<div class="jumbotron">
			<h5> Camila Corrêa Vieira - Teste Voitto</h5>
			<form method="POST"  name="nomeForm" class="form-group">
				<label>Nome:</label>
				<select class="browser-default custom-select" name="val" id="val" onFocus="indiceAnterior=this.selectedIndex" onChange="verifica(this,indiceAnterior);">
					<option value="">Escolha o nome</option>
					<?php
						$result_cat_post="SELECT * FROM pessoa_teste ORDER BY nome";
						$resultado_cat_post = mysqli_query($conn, $result_cat_post);
						while($row_cat_post = mysqli_fetch_assoc($resultado_cat_post) ) {
							echo '<option value="'.$row_cat_post['id'].'">'.$row_cat_post['nome'].'</option>';
						}
					?>
				</select>
			</form>
			
			<!-- Inicio do formulario CEP -->
			  <form method="get" action=".">
				<div class="row">
					<div class="col-md-4">
						<label>CEP*
						<input name="cep" type="text" id="cep" value="" onblur="pesquisacep(this.value);" class="form-control mb-4 mr-sm-4"/></label><br />
					</div>
					<div class="col-md-4">
						<label>Rua*
						<input name="rua" type="text" id="rua" class="form-control mb-4 mr-sm-4" /></label><br />
					</div>
					<div class="col-md-4">
						<label>Número*
						<input name="numero" type="text" id="numero"  class="form-control mb-4 mr-sm-4"/></label><br />
					</div>
				</div>
				<div class="row">
					<div class="col-md-8">
						<label>Bairro*
						<input name="bairro" type="text" id="bairro"  class="form-control mb-4 mr-sm-4"/></label><br />
					</div>
					<div class="col-md-8">
						<label>Complemento
						<input name="complemento" type="text" id="complemento" class="form-control mb-4 mr-sm-4"/></label><br />
					</div>
				</div>
				<div class="row">
					<div class="col-sm-4">
						<label>Cidade*
						<input name="cidade" type="text" id="cidade" class="form-control mb-4 mr-sm-4"/></label><br />
					</div>
					<div class="col-sm-4">
						<label>Estado*
						<input name="uf" type="text" id="uf" class="form-control mb-4 mr-sm-4" /></label><br />
					</div>
				</div>
			 </form>
			<script type="text/javascript" src="javascript.js"></script>
		</div>
	</div>
	
</body>
</html>